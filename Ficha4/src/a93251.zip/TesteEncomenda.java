import java.time.LocalDate;
import java.util.ArrayList;

public class TesteEncomenda {
    public static void main(String[] args) {
        LinhaEncomenda linha = new LinhaEncomenda("0110","Meias",5,1,0.10,0.20);
        LinhaEncomenda linha2 = new LinhaEncomenda("0101","Sapatos",10,2,0.23,0.15);
        EncEficiente encomenda = new EncEficiente();
        //Adicionar Elementos
        encomenda.adicionaLinha(linha);
        encomenda.adicionaLinha(linha2);
        //System.out.println(encomenda.toString());
        //Clone
        EncEficiente encomenda2 = encomenda.clone();
        //Equals
        System.out.println("Encomenda é igual à encomenda2? " + encomenda.equals(encomenda2));
        //Remover Elementos
        encomenda2.removeProduto("0110");
        //Número de produtos total
        System.out.println(encomenda.numeroTotalProdutos());
        System.out.println(encomenda2.numeroTotalProdutos());
        // Calcular o valor Total
        System.out.println("O valor total é: " + encomenda.calculaValorTotal());
        // Calcular o valor de Desconto
        System.out.println("O valor de desconto é: " + encomenda.calculaValorDesconto());
        //To String
        System.out.println(encomenda.toString());
    }
}
